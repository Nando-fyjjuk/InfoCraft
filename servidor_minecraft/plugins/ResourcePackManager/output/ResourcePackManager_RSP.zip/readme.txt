Resourcepack originally created by ziomalu(itqerk).
Resourcepack have been merged and improved by iijj22gg.

Changelog:
- Combines both custommodeldata methods, changed the paths of the old files to use the new structure
- Fixed the models to work in all versions. Removed the parent property from the backpack models, and added the gui_light property.
- Changed the texture size of gui_fill from 17x17 to 16x16. Looks exactly the same, but doesn't disable mipmaps.